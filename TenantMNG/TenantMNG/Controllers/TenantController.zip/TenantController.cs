﻿using System.Linq;
using System.Collections.Generic;
using System.Web.Mvc;
using TenantMNG.ADO.NET;
using TenantMNG.BAL;
using TenantMNG.Core;
using TenantMNG.Models;
using TenantMNG.ViewModel;
using PagedList;
using System.Data;
using System.Web.UI.WebControls;
using System.Collections;
using System.Web.Helpers;
using System.Web.Script.Serialization;
using System.Globalization;
using System.Web;
using System.IO;
using log4net;
using System;
using System.Web.UI;


namespace TenantMNG.Controllers
{
    public class TenantController : MyController
    {
        DB_TenantMNGEntities _dbc = new DB_TenantMNGEntities();
        ILog log = log4net.LogManager.GetLogger(typeof(TenantController));
        // GET: Tenant
        public ActionResult Dashboard()
        {
            int pmid = Convert.ToInt32(Session["uid"].ToString());

            var _user = _dbc.tbl_user_master.Where(x => x.int_user_type_id ==3 && x.int_pm_id == pmid).ToList();

            var _invoice = _dbc.tbl_invoice.Where(x => x.tbl_user_master.int_pm_id ==pmid).ToList();

            TenantVM _objvm = new TenantVM();
            _objvm.tbl_invoice = _invoice.ToList();

            _objvm.tbl_user_master = _user.ToList();


            bindDropBox();
            return View(_objvm);
        }

        public void bindDropBox()
        {
            int _pm_id = Convert.ToInt32(Session["uid"].ToString());

            var _tenant = _dbc.tbl_user_master.Where(x => x.int_pm_id == _pm_id).ToList();

            ViewBag.TenantDropDown = new SelectList(_tenant, "int_id", "str_comp_name");
        }

        public ActionResult ChangePassword()
        {
            int _id = Convert.ToInt32(Session["uid"].ToString());
            var _user = _dbc.tbl_user_master.Where(x => x.int_id == _id).FirstOrDefault();

            UserMasterVM vmobj = new UserMasterVM()
            {

                int_id = _id,
                str_password = _user.str_password,


            };


            return View(vmobj);
        }

        [SessionCheck]
        [HttpPost]
        public JsonResult CharterEnergyConsumption(string s_date, string tenantid)
        {
            if (Session["utypeid"].ToString() == CommonCls._usertypeTenant.ToString() || !string.IsNullOrEmpty(tenantid))
            {
                int id = string.IsNullOrEmpty(tenantid) ? Convert.ToInt32(Session["uid"].ToString()) : Convert.ToInt32(tenantid);

                return this.Json(
    (from obj in _dbc.tbl_invoice where obj.int_tenant_id == id orderby obj.int_invoice_id descending select new { Invoice_No = obj.int_invoice_id.ToString(), Energy = obj.dec_total, InvoiceMonth = obj.date_invoice_date.Value.Month }).Take(5)
    , JsonRequestBehavior.AllowGet
    );
            }
            else
            {
                return this.Json(
   (from obj in _dbc.tbl_invoice orderby obj.int_invoice_id descending select new { Invoice_No = obj.int_invoice_id.ToString(), Energy = obj.dec_total, InvoiceMonth = obj.date_invoice_date.Value.Month }).Take(5)
   , JsonRequestBehavior.AllowGet
   );
            }
        }

        [HttpPost]
        public JsonResult PieCharterEnergyConsumption()
        {
            return this.Json(
(from obj in _dbc.tbl_invoice select new { PeackEnergy = obj.dec_total })
, JsonRequestBehavior.AllowGet
);
        }

        // for meter summary

        [SessionCheck]
        [HttpGet]
        public ActionResult Summary(int? page)
        {
            try
            {
                int _pm_id = Convert.ToInt32(Session["uid"].ToString());

                var _tenant = _dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList();
                var tenant = _tenant.ToList();
                var bygroup = from ins in tenant
                              group ins by ins.tbl_user_master.str_comp_name into empg
                              select new
                              {

                                  Name = empg.Key,
                                  meterid = empg.Max(x => x.tbl_invoice_details.ElementAt(0).int_meter_id),
                                  fromdate = empg.Min(x => x.date_s_bill_date),
                                  todate = empg.Max(x => x.date_e_bill_date),
                                  peakenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_peak_energy),
                                  interenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_inter_energy),
                                  customecharges = empg.Sum(x => x.dec_custome_charges),
                                  decdemad = empg.Sum(x => x.dec_demad),
                                  dectaxamt = empg.Sum(x => x.dec_tax_amt),
                                  dectotal = empg.Sum(x => x.dec_total),
                              };
                var data = bygroup.ToList();
                List<SummaryViewModel> models = new List<SummaryViewModel>();
                SummaryViewModel abc;
                foreach (var dt in data)
                {
                    abc = new SummaryViewModel();
                    abc.Name = dt.Name;
                    abc.meterid = dt.meterid;
                    abc.fromdate = dt.fromdate;
                    abc.todate = dt.todate;
                    abc.peakenergy = dt.peakenergy;
                    abc.interenergy = dt.interenergy;
                    abc.customecharges = dt.customecharges;
                    abc.decdemad = dt.decdemad;
                    abc.dectaxamt = dt.dectaxamt;
                    abc.dectotal = dt.dectotal;
                    models.Add(abc);
                }
                ViewBag._abc = models;
                return View(_dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList().ToPagedList(page ?? 1, CommonCls._pagesize));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            return View();
        }

        //[SessionCheck]
        //[HttpGet]
        //public ActionResult Summary(int? page, string s_date, string e_date, string int_id)
        //{
        //    try
        //    {
        //        var _tenant = _dbc.tbl_invoice.AsQueryable();

        //        int _pm_id = Convert.ToInt32(Session["uid"].ToString());

        //        if (!string.IsNullOrEmpty(int_id))
        //        {

        //            _tenant = _dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id);

        //        }
        //        if (!string.IsNullOrEmpty(s_date) && !string.IsNullOrEmpty(e_date))
        //        {
        //            DateTime _sdate = Convert.ToDateTime(s_date);
        //            DateTime _edate = Convert.ToDateTime(e_date);


        //            _tenant = _tenant.Where(x => x.date_s_bill_date >= _sdate && x.date_e_bill_date <= _edate);

        //        }

        //        //_tenant = _tenant.Where(x => x.int_tenant_id == _pm_id).ToList();

        //        return View(_tenant.Where(x => x.int_tenant_id == _pm_id).ToList().ToPagedList(page ?? 1, CommonCls._pagesize));
        //    }
        //    catch (Exception ex)
        //    {
        //        log.Error(ex.Message);
        //    }
        //    return View();
        //}



        //Meter Reading
        [SessionCheck]
        [HttpGet]
        public ActionResult MeterReading(int? page)
        {
            try
            {
                int _pm_id = Convert.ToInt32(Session["uid"].ToString());

                var _tenant = _dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList();
                var tenant = _tenant.ToList();
                var bygroup = from ins in tenant
                              group ins by ins.tbl_user_master.str_comp_name into empg
                              select new
                              {

                                  Name = empg.Key,
                                  meterid = empg.Max(x => x.tbl_invoice_details.ElementAt(0).int_meter_id),
                                  fromdate = empg.Min(x => x.date_s_bill_date),
                                  todate = empg.Max(x => x.date_e_bill_date),
                                  peakenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_peak_energy),
                                  interenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_inter_energy),
                                  customecharges = empg.Sum(x => x.dec_custome_charges),
                                  decdemad = empg.Sum(x => x.dec_demad),
                                  dectaxamt = empg.Sum(x => x.dec_tax_amt),
                                  dectotal = empg.Sum(x => x.dec_total),
                              };
                var data = bygroup.ToList();

                List<SummaryViewModel> models = new List<SummaryViewModel>();
                SummaryViewModel abc;
                foreach (var dt in data)
                {
                    abc = new SummaryViewModel();
                    abc.Name = dt.Name;
                    abc.meterid = dt.meterid;
                    abc.fromdate = dt.fromdate;
                    abc.todate = dt.todate;
                    abc.peakenergy = dt.peakenergy;
                    abc.interenergy = dt.interenergy;
                    abc.customecharges = dt.customecharges;
                    abc.decdemad = dt.decdemad;
                    abc.dectaxamt = dt.dectaxamt;
                    abc.dectotal = dt.dectotal;
                    models.Add(abc);
                }


                ViewBag._abc = models;
                return View(_dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList().ToPagedList(page ?? 1, CommonCls._pagesize));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            return View();
        }


        public ActionResult TenantconsumptionReport(int? page)
        {
            try
            {
                int _pm_id = Convert.ToInt32(Session["uid"].ToString());

                var _tenant = _dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList();
                var tenant = _tenant.ToList();
                var bygroup = from ins in tenant
                              group ins by ins.tbl_user_master.str_comp_name into empg
                              select new
                              {

                                  Name = empg.Key,
                                  peakenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_peak_energy),
                                  interenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_inter_energy),
                                  baseenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_base_energy),
                                  invoicedate = empg.Max(x => x.date_invoice_date.Value.Month.ToString()),
                              };
                var data = bygroup.ToList();

                List<SummaryViewModel> models = new List<SummaryViewModel>();
                SummaryViewModel abc;
                foreach (var dt in data)
                {
                    abc = new SummaryViewModel();
                    abc.Name = dt.Name;
                    abc.totalenergy = dt.interenergy + dt.peakenergy + dt.baseenergy;
                    if (dt.invoicedate == "5")
                        abc.dateinvoice = "May";
                    if (dt.invoicedate == "1")
                        abc.dateinvoice = "january";
                    if (dt.invoicedate == "2")
                        abc.dateinvoice = "February";
                    if (dt.invoicedate == "3")
                        abc.dateinvoice = "March";
                    if (dt.invoicedate == "4")
                        abc.dateinvoice = "April";
                    if (dt.invoicedate == "6")
                        abc.dateinvoice = "June";
                    if (dt.invoicedate == "7")
                        abc.dateinvoice = "July";
                    if (dt.invoicedate == "8")
                        abc.dateinvoice = "August";
                    if (dt.invoicedate == "9")
                        abc.dateinvoice = "September";
                    if (dt.invoicedate == "10")
                        abc.dateinvoice = "October";
                    if (dt.invoicedate == "11")
                        abc.dateinvoice = "November";
                    if (dt.invoicedate == "12")
                        abc.dateinvoice = "December";
                    models.Add(abc);
                }


                ViewBag._abc = models;
                return View(_dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList().ToPagedList(page ?? 1, CommonCls._pagesize));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            return View();
        }

        public ActionResult Chart(int? page)
        {
            try
            {
              int  _pm_id = Convert.ToInt32(Session["uid"].ToString());

                var _tenant = _dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList();
                var tenant = _tenant.ToList();
                var bygroup = from ins in tenant
                              group ins by ins.tbl_user_master.str_comp_name into empg
                              select new
                              {

                                  Name = empg.Key,
                                  peakenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_peak_energy),
                                  interenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_inter_energy),
                                  baseenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_base_energy),
                                  invoicedate = empg.Max(x => x.date_invoice_date.Value.Month.ToString()),
                              };
                var data = bygroup.ToList();

                List<SummaryViewModel> models = new List<SummaryViewModel>();
                SummaryViewModel abc;
                foreach (var dt in data)
                {
                    abc = new SummaryViewModel();
                    abc.Name = dt.Name;
                    abc.totalenergy = dt.interenergy + dt.peakenergy + dt.baseenergy;
                    abc.dateinvoice = dt.invoicedate;
                    if (dt.invoicedate == "5")
                        abc.dateinvoice = "May";
                    if (dt.invoicedate == "1")
                        abc.dateinvoice = "january";
                    if (dt.invoicedate == "2")
                        abc.dateinvoice = "February";
                    if (dt.invoicedate == "3")
                        abc.dateinvoice = "March";
                    if (dt.invoicedate == "4")
                        abc.dateinvoice = "April";
                    if (dt.invoicedate == "6")
                        abc.dateinvoice = "June";
                    if (dt.invoicedate == "7")
                        abc.dateinvoice = "July";
                    if (dt.invoicedate == "8")
                        abc.dateinvoice = "August";
                    if (dt.invoicedate == "9")
                        abc.dateinvoice = "September";
                    if (dt.invoicedate == "10")
                        abc.dateinvoice = "October";
                    if (dt.invoicedate == "11")
                        abc.dateinvoice = "November";
                    if (dt.invoicedate == "12")
                        abc.dateinvoice = "December";
                    models.Add(abc);
                }


                ViewBag._abc = models;
                return View(_dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList().ToPagedList(page ?? 1, CommonCls._pagesize));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            return View();
        }

        public JsonResult Chartnew (int? page)
        {
            try
            {
               int _pm_id = Convert.ToInt32(Session["uid"].ToString());

                var _tenant = _dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList();
                var tenant = _tenant.ToList();
                var bygroup = from ins in tenant
                              group ins by new { ins.date_invoice_date, ins.int_tenant_id, ins.tbl_user_master.str_comp_name }
                                     into empg
                              select new
                              {
                                  Name = empg.Key.str_comp_name,
                                  peakenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_peak_energy),
                                  interenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_inter_energy),
                                  baseenergy = empg.Sum(x => x.tbl_invoice_details.ElementAt(0).dec_base_energy),
                                  invoicedate = empg.Key.date_invoice_date.Value.Month.ToString()
                              };
                var data = bygroup.ToList();
                List<SummaryViewModel> models = new List<SummaryViewModel>();
                SummaryViewModel abc;
                for (int i = 1; i <= 12; i++)
                {
                    abc = new SummaryViewModel();
                    var fltrdata = data.Where(P => P.invoicedate == i.ToString()).FirstOrDefault();
                    if (fltrdata != null)
                    {
                        abc.Name = fltrdata.Name;
                        abc.totalenergy = fltrdata.interenergy + fltrdata.peakenergy + fltrdata.baseenergy;
                        abc.dateinvoice = fltrdata.invoicedate;
                        models.Add(abc);
                    }
                    else
                    {
                        abc.Name = null;
                        abc.totalenergy = 0;
                        abc.dateinvoice = i.ToString();
                        models.Add(abc);
                    }
                }

                ViewBag._abc = models.OrderBy(P => P.dateinvoice);
                return Json(models, JsonRequestBehavior.AllowGet);
                //return View(_dbc.tbl_invoice.Where(x => x.int_tenant_id == _pm_id).ToList().ToPagedList(page ?? 1, CommonCls._pagesize));
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
            return Json(null);
        }


    }
}